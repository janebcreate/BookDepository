package ru.rsue.budyakova

import java.util.*

class Book {
    var id: UUID
        private set
    var title=""
    init {
        id=UUID.randomUUID()
    }
}